<?php
echo "<form id ='goBack' action='index.php' method='post' >";
echo " <input type='submit' value='Return Home'> <br />";
echo "</form>";
?>