<?php
echo "<img src=\"mater.png\" alt=\"Italian Trulli\"> <h1>Truck Tracker Database</h1> ";
?>
